a=input()
print(a.count("?"))