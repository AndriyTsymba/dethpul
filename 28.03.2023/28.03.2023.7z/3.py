a=str(input())
b=str(input())
k=0
for i in a:
    if i==b:
        k=k+1
print(k)