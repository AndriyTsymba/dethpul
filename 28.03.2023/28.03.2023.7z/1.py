a=str(input())
print(a[::-1])