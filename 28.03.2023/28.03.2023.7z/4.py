a=str(input())
b=str(input())
k=0
for i in a:
    c=a.count(b)
print(c)