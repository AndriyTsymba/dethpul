a=str(input())
b=str(input())
c=str(input())
k=0
for i in a:
    d=a.replace(b,c)
print(d)