print("Skilki dlya mavp")
def f1(h, c):
    suma=h+c
    print(suma)
f1(int(input()), int(input()))
print("Skilki dlya izhakiv")
f1(int(input()), int(input()))
print("skilki dlya rib")
f1(int(input()), int(input()))