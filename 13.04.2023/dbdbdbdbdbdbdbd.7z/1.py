def f1(a):
    n=len(a)+4
    print(n*"_")
    print("I",a,"I")
    print(n*"_")
f1(input())