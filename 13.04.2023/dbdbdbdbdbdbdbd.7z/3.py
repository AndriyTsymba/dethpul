def f1(a, h):
    v=((6*(a*a)*h)/(12*(1.7/3)))
    print(v)
f1(int(input()), int(input()))